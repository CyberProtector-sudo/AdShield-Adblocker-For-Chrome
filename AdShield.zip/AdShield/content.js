// content.js

const blockedSelectors = [
    // Google Ads
    'iframe[src*="doubleclick"]', // Google DoubleClick
    'ins.adsbygoogle', // Google AdSense
    'div[class*="adsbygoogle"]', // Google AdSense container

    // Facebook Ads
    'div[class*="fb-ad"]', // Facebook Ads

    // Other Common Ad Networks
    'div[class*="ad"]', // Generic ad divs
    'div[id*="ad"]', // Generic ad ids
    'div[class*="advertisement"]', // Advertisement divs
    'div[class*="ad-container"]', // Ad container
    'div[class*="ad-slot"]', // Ad slot
    'div[class*="banner-ad"]', // Banner ads
    'div[class*="promo"]', // Promotions
    'div[class*="sponsored"]', // Sponsored content
    'div[class*="ad-banner"]', // Ad banners
    'div[class*="ad-wrapper"]', // Ad wrappers
    'div[class*="overlay"]', // Overlay ads
    'a[href*="ads"]', // Links with ads
    'script[src*="ads"]', // Ad scripts
    'img[src*="ads"]', // Images that are ads
    'div[class*="responsive-ad"]', // Responsive ads
    'div[class*="google-auto-"]', // Google auto ads
    'div[class*="footer-ad"]', // Footer ads
    'div[class*="sticky-ad"]', // Sticky ads
    'div[class*="interstitial"]', // Interstitial ads

    // Specific Ad Networks
    'iframe[src*="adnxs.com"]', // AppNexus
    'iframe[src*="adserver.adtechus.com"]', // AdTech
    'div[class*="rubiconproject"]', // Rubicon Project
    'div[class*="criteo"]', // Criteo
    'div[class*="taboola"]', // Taboola
    'div[class*="outbrain"]', // Outbrain
    'div[class*="sovrn"]', // Sovrn
    'div[class*="indexexchange"]', // Index Exchange
    'div[class*="media.net"]', // Media.net
    'div[class*="openx"]', // OpenX
    'div[class*="yieldmo"]', // Yieldmo
    'div[class*="adbutler"]', // AdButler
    'div[class*="advertising"]', // General advertising

    // Others as needed
];

// Function to hide ads
function hideAds() {
    blockedSelectors.forEach(selector => {
        const ads = document.querySelectorAll(selector);
        ads.forEach(ad => ad.style.display = 'none');
    });
}

// Run the function to hide ads when the page loads
window.addEventListener('load', hideAds);
