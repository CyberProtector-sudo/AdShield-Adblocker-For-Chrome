let isBlocking = true;

const toggleButton = document.getElementById('toggle');
toggleButton.addEventListener('click', () => {
    isBlocking = !isBlocking;
    chrome.storage.local.set({ blocking: isBlocking });
    toggleButton.textContent = isBlocking ? 'Disable Blocking' : 'Enable Blocking';
});

// Load the current state
chrome.storage.local.get(['blocking'], (result) => {
    if (result.blocking !== undefined) {
        isBlocking = result.blocking;
        toggleButton.textContent = isBlocking ? 'Disable Blocking' : 'Enable Blocking';
    }
});
