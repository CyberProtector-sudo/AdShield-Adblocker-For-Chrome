// background.js

// Log when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
    console.log("AdShield extension installed.");
});

// No ad blocking logic here, as we're using content scripts instead.
